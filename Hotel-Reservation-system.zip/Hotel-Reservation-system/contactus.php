<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Online Reservation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap1.css " />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header">
				<center>
					<a class = "navbar-brand" >HomelyHaven</a>
      			</center>
			</div>
		</div>
	</nav>	
	<ul id = "menu">
		<li><a href = "index.php">Home</a></li> |
		<li><a href = "aboutus.php">About us</a></li> |
		<li><a href = "contactus.php">Contact us</a></li> |
		<li><a href = "gallery.php">Gallery</a></li> |
		<li><a href = "dineandlounge.php">Food-o-pedia</a></li> |			
		<li><a href = "reservation.php">Make a reservation</a></li> |
		<li><a href = "rulesandregulation.php">Rules and Regulation</a></li> |
		<li><a href = "review.php">Reviews</a></li>
	</ul>
	<center>
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			 <div class = "panel-body1">
				<strong><u><h3>CONTACT US</h3></u></strong>
				<br />
				<center><img src = "images/hotel.jpg" width = "300" height = "300" /></center>
				<br />
				<br />
				<center>
				<br />
				
				<p>Contact No: +91 9036375025</p>
				<p>Email: homelyhavenrooms.com</p>
				</center>
			 </div>
			 
		</div>
	</div>
	</center>
	<br />
	<br />
	
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>	
</html>