<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Online Reservation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap1.css " />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header">
				<center>
					<a class = "navbar-brand" >HomelyHaven</a>
      			</center>
			</div>
		</div>
	</nav>	
	<ul id = "menu">
		<li><a href = "index.php">Home</a></li> |
		<li><a href = "aboutus.php">About us</a></li> |
		<li><a href = "contactus.php">Contact us</a></li> |
		<li><a href = "gallery.php">Gallery</a></li> |
		<li><a href = "dineandlounge.php">Food-o-pedia</a></li> |			
		<li><a href = "reservation.php">Make a reservation</a></li> |
		<li><a href = "rulesandregulation.php">Rules and Regulation</a></li> |
		<li><a href = "review.php">Reviews</a></li>
	</ul>
	<center>
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			 <div class = "panel-body1">
			 <h2>Customer Reviews</h2>
        <!-- Form for submitting reviews -->
        <form action="add_review.php" method="POST">
            <label for="reviewer_name">Name:</label>
            <input type="text" id="reviewer_name" name="reviewer_name" required>
            <br>
            <label for="review_text">Review:</label>
            <textarea id="review_text" name="review_text" rows="4" cols="50" required></textarea>
            <br>
            <input type="submit" value="Submit Review">
        </form>

        <div id="reviews_section">
            <?php
            // Connect to the reviews database
            $conn_reviews = new mysqli('localhost', 'root', '', 'hotel_db');

            if ($conn_reviews->connect_error) {
                die("Connection failed: {$conn_reviews->connect_error}");
            }

            // Fetch reviews and sentiments from the database
            $sql_reviews = "SELECT reviewer_name, review_text, sentiment FROM reviews";
            $result_reviews = $conn_reviews->query($sql_reviews);

            if ($result_reviews->num_rows > 0) {
                // Output each review with sentiment
                while($row_reviews = $result_reviews->fetch_assoc()) {
                    echo "<p><strong>" . htmlspecialchars($row_reviews["reviewer_name"]) . ":</strong> " . htmlspecialchars($row_reviews["review_text"]) . " (" . htmlspecialchars($row_reviews["sentiment"]) . ")</p>";
                }
            } else {
                echo "No reviews yet.";
            }

            // Close reviews database connection
            $conn_reviews->close();
            ?>
        </div>
		</div>
	</div>
	</center>
	<br />
	<br />
	
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>	
</html>