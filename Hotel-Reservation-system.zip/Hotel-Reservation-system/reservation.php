<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hotel Online Reservation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap1.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <nav style="background-color:rgba(0, 0, 0, 0.1);" class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand">HomelyHaven</a>
            </div>
        </div>
    </nav>    
    <ul id="menu">
        <li><a href="index.php">Home</a></li> |
        <li><a href="aboutus.php">About us</a></li> |
        <li><a href="contactus.php">Contact us</a></li> |
        <li><a href="gallery.php">Gallery</a></li> |
        <li><a href="dineandlounge.php">Food-o-pedia</a></li> |           
        <li><a href="reservation.php">Make a reservation</a></li> |
        <li><a href="rulesandregulation.php">Rules and Regulation</a></li> |
		<li><a href = "review.php">Reviews</a></li>
    </ul>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <strong><u><h3>MAKE A RESERVATION</h3></u></strong>
                <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '', 'hotel_db');

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch rooms from the database
                $query = "SELECT * FROM `room` ORDER BY `price` ASC";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($fetch = $result->fetch_array()) {
                        ?>
                        <div class="well" style="height:300px; width:100%;">
                            <div style="float:left;">
                                <img src="photo/<?php echo $fetch['photo']?>" height="250" width="350"/>
                            </div>
                            <div style="float:left; margin-left:10px;">
                                <h3><?php echo $fetch['room_type']?></h3>
                                <h4 style="color:#00ff00;"><?php echo "Price: INR ".$fetch['price'].".00"?></h4>
                                <br /><br /><br /><br /><br /><br />
                                <a style="margin-left:580px;" href="add_reserve.php?room_id=<?php echo $fetch['room_id']?>" class="btn btn-info"><i class="glyphicon glyphicon-list"></i> Reserve</a>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "No rooms available.";
                }

                // Close database connection
                $conn->close();
                ?>
            </div>
        </div>

        
    </div>
    <br />
    <br />

    <!-- Include JavaScript libraries -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>
