import sys
from textblob import TextBlob

def analyze_sentiment(review_text):
    blob = TextBlob(review_text)
    sentiment_score = blob.sentiment.polarity
    
    if sentiment_score > 0.2:
        return "Positive"
    elif sentiment_score < -0.2:
        return "Negative"
    else:
        return "Neutral"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python sentiment_analysis.py <review_text>")
        sys.exit(1)
    
    review_text = sys.argv[1]

    try:
        sentiment_label = analyze_sentiment(review_text)
        print(sentiment_label)  # Return only the sentiment label
    except Exception as e:
        print(f"Error analyzing sentiment: {e}")
