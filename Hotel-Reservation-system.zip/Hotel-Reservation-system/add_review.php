<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli('localhost', 'root', '', 'hotel_db');

    if ($conn->connect_error) {
        die("Connection failed: {$conn->connect_error}");
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO reviews (reviewer_name, review_text) VALUES (?, ?)");
    $stmt->bind_param("ss", $reviewer_name, $review_text);

    // Set parameters and execute
    $reviewer_name = $_POST['reviewer_name'];
    $review_text = $_POST['review_text'];
    $stmt->execute();

    // Get the ID of the inserted review
    $review_id = $stmt->insert_id;

    // Close prepared statement
    $stmt->close();

    // Call the Python script to analyze sentiment
    $output = shell_exec("python sentiment_analysis.py \"" . addslashes($review_text) . "\"");
    $sentiment_label = trim($output);  // Remove any extra whitespace

    // Debugging: Output the sentiment label to verify
    echo "Sentiment Analysis Output: " . htmlspecialchars($sentiment_label) . "<br>";

    // Update the `sentiment` field in the `reviews` table
    $update_query = "UPDATE reviews SET sentiment = '{$sentiment_label}' WHERE id = {$review_id}";
    if ($conn->query($update_query) === TRUE) {
        // Redirect back to the reservation page upon successful update
        $conn->close();
        header("Location: reservation.php");
        exit();
    } else {
        echo "Error updating record: {$conn->error}";
    }

    $conn->close();
}
