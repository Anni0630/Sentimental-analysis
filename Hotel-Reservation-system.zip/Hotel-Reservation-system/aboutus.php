<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Online Reservation</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap1.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body style="background-image: url('img/background.jpg');">
    <nav style="background-color: rgba(0, 0, 0, 0.1);" class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand">HomelyHaven</a>
            </div>
        </div>
    </nav>
    <ul id="menu">
        <li><a href="index.php">Home</a></li> |
        <li><a href="aboutus.php">About us</a></li> |
        <li><a href="contactus.php">Contact us</a></li> |
        <li><a href="gallery.php">Gallery</a></li> |
        <li><a href="dineandlounge.php">Food-o-pedia</a></li> |
        <li><a href="reservation.php">Make a reservation</a></li> |
        <li><a href="rulesandregulation.php">Rules and Regulation</a></li> |
		<li><a href = "review.php">Reviews</a></li>
    </ul>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <strong><u><h3>ABOUT US</h3></u></strong>
                <p style="position:relative; font-size:20px; float:left; width:850px;">Whether you're seeking a HomelyHaven for a romantic getaway, a peaceful haven for a corporate Haven, or simply a place to rest and recharge during your travels, HomelyHaven welcomes you with open arms. Join us in experiencing the perfect harmony of luxury, tranquility, and impeccable service. Your journey to serenity begins here, at HomelyHaven.</p>
                <img style="float:right;" src="images/about.jpg" width="250px" height="250px" />
                <br style="clear:both;" />
                <br />
                <br />
                <hr style="border:1px dotted #000;" />
                <br />
                <div style="float:left; margin-left:40px; width:300px; height:300px; ">
                    <center><img src="images/1.jpg" width="250px" height="250px" style="margin-top:5px;"/></center>
                    <center><h4 style="color:rgba(0, 255, 0, 1);">Standard</h4></center>
                    <center><label>Small Size Bed</label> <label style="color:red;">INR 2,000.00</label></center>
                </div>
                <!-- Other room details divs here -->
                <br style="clear:both;"/>
                <br />
                <br />
                <strong class="an3"><u>Amenities and Services</u></strong>
                <ul class="an2">
                    <!-- List of amenities here -->
                </ul>
            </div>
        </div>
    </div>
    <br />
    <br />
</body>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>   
</html>
