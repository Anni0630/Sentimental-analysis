# test_script.py
from textblob import TextBlob

text = "I love this place."
blob = TextBlob(text)
print(blob.sentiment.polarity)
